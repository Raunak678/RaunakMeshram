# Spring-Boot-Project-Management

## Description:

A demo Project management app written in Java 11, Spring Boot, Spring Security, MySQL


## How to run:

`mvnw spring-boot:run -f pom.xml`


## Tech stacks:

* Spring boot
* Spring security
* Java 11
* Tomcat embeded
* MySQL

